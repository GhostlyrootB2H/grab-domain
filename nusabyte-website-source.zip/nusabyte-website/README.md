# NusaByte Website

Website landing page statis menggunakan HTML, CSS, dan JavaScript murni.

## Struktur
- `index.html` — struktur dan konten halaman
- `css/style.css` — styling, layout responsif, dan animasi ringan
- `js/main.js` — menu mobile dan tahun footer

## Cara menjalankan
Buka `index.html` di browser, atau unggah seluruh isi folder ini ke document root hosting (biasanya `public_html`).

## Sebelum dipublikasikan
1. Ganti nomor WhatsApp `6281234567890` di `index.html` dengan nomor bisnis yang benar (format internasional tanpa `+`).
2. Perbarui paket, harga, fitur, dan ketentuan sesuai layanan nyata.
3. Ganti portfolio konsep dengan proyek asli atau hapus jika belum ada.
4. Tambahkan alamat/email/media sosial yang benar jika ingin ditampilkan.
5. Pastikan domain dan SSL aktif di panel hosting.

Tidak membutuhkan WordPress, database, atau build tools.
